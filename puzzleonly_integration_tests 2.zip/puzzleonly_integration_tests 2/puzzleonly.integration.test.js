// PuzzleOnly integrācijas testi
// Palaišana: TEST_EMAIL="tavs_epasts" TEST_PASSWORD="tava_parole" npm test

import test from 'node:test';
import assert from 'node:assert/strict';
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://bscruhppvicfphqcrdwb.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJIUzI1NiIsInJlZiI6ImJzY3J1aHBwdmljZnBocWNyZHdiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY2NTA0ODksImV4cCI6MjA5MjIyNjQ4OX0.YPwJyRqNmf8wL8ljZ2dkrwLKU1TfEY-iuSMgC2tB2NY';

const TEST_EMAIL = process.env.TEST_EMAIL;
const TEST_PASSWORD = process.env.TEST_PASSWORD;

if (!TEST_EMAIL || !TEST_PASSWORD) {
  throw new Error('Norādi TEST_EMAIL un TEST_PASSWORD vides mainīgos pirms testa palaišanas.');
}

const db = createClient(SUPABASE_URL, SUPABASE_KEY);

async function loginTestUser() {
  const { data, error } = await db.auth.signInWithPassword({
    email: TEST_EMAIL,
    password: TEST_PASSWORD,
  });

  assert.equal(error, null, `Autentifikācijas kļūda: ${error?.message}`);
  assert.ok(data.user, 'Pēc pieslēgšanās jābūt pieejamam lietotājam');
  assert.ok(data.session, 'Pēc pieslēgšanās jābūt aktīvai sesijai');

  return data.user;
}

test('Integrācijas tests 1: lietotājs var pieslēgties un tiek atrasts profils', async () => {
  const user = await loginTestUser();

  const { data: profile, error } = await db
    .from('user_profiles')
    .select('*')
    .eq('user_id', user.id)
    .maybeSingle();

  assert.equal(error, null, `Profila nolasīšanas kļūda: ${error?.message}`);
  assert.ok(profile, 'Pēc pieslēgšanās jāatrod lietotāja profils tabulā user_profiles');
  assert.equal(profile.email, TEST_EMAIL, 'Profila e-pastam jāsakrīt ar testa lietotāja e-pastu');
});

test('Integrācijas tests 2: atrisināta pužļa rezultātu var saglabāt, nolasīt un dzēst', async () => {
  const user = await loginTestUser();

  const testResult = {
    user_id: user.id,
    image_name: 'Integration test image',
    image_url: null,
    grid_size: '3×3',
    cols: 3,
    rows: 3,
    time_elapsed: '00:01',
    time_seconds: 1,
  };

  const startTime = performance.now();

  const { data: insertedRows, error: insertError } = await db
    .from('puzzle_results')
    .insert([testResult])
    .select('*');

  const saveTimeMs = performance.now() - startTime;

  assert.equal(insertError, null, `Saglabāšanas kļūda: ${insertError?.message}`);
  assert.ok(insertedRows?.length === 1, 'Datubāzē jābūt ievietotam tieši vienam rezultātam');
  assert.ok(saveTimeMs <= 1000, `Saglabāšanas laikam jābūt <= 1000 ms, faktiski: ${Math.round(saveTimeMs)} ms`);

  const insertedId = insertedRows[0].id;

  const { data: savedResult, error: selectError } = await db
    .from('puzzle_results')
    .select('*')
    .eq('id', insertedId)
    .single();

  assert.equal(selectError, null, `Nolasīšanas kļūda: ${selectError?.message}`);
  assert.equal(savedResult.user_id, user.id, 'Saglabātajam rezultātam jābūt piesaistītam pareizajam lietotājam');
  assert.equal(savedResult.grid_size, '3×3', 'Saglabātajam režģa izmēram jābūt 3×3');
  assert.equal(savedResult.time_seconds, 1, 'Saglabātajam laikam sekundēs jābūt 1');

  const { error: deleteError } = await db
    .from('puzzle_results')
    .delete()
    .eq('id', insertedId);

  assert.equal(deleteError, null, `Testa datu dzēšanas kļūda: ${deleteError?.message}`);
});
